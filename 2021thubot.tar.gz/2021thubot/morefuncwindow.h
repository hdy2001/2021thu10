#ifndef MOREFUNCWINDOW_H
#define MOREFUNCWINDOW_H

#include <QWidget>
#include <QDesktopWidget>
#include "modeswindow.h"

namespace Ui {
class MoreFuncWindow;
}

class MoreFuncWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MoreFuncWindow(QWidget *parent = 0);
    ~MoreFuncWindow();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_toolButton_clicked();

    void on_toolButton_2_clicked();

    void on_toolButton_5_clicked();

    void on_toolButton_3_clicked();

    void on_toolButton_4_clicked();

    void on_toolButton_6_clicked();

private:
    Ui::MoreFuncWindow *ui;
};

#endif // MOREFUNCWINDOW_H
