#ifndef MODESWINDOW_H
#define MODESWINDOW_H

#include <QMainWindow>
#include "autotouristwindow.h"
#include <QDesktopWidget>
#include "autofuncwindow.h"
#include "morefuncwindow.h"

#include <QtGui>


namespace Ui {
class ModesWindow;
}

class ModesWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit ModesWindow(QWidget *parent = 0);

    /*
    void paintEvent(QPaintEvent *event)
    {
        QPainter painter(this);
        painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/picture/image/2.jpg"));
    }
    */

    ~ModesWindow();

private slots:
    void on_pushButton_2_clicked();

    void on_toolButton_clicked();

    void on_pushButton_clicked();

    void on_toolButton_2_clicked();

private:
    Ui::ModesWindow *ui;
};



#endif // MODESWINDOW_H
