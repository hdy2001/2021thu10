#include "modeswindow.h"
#include "ui_modeswindow.h"
#include "setplacewindow.h"

ModesWindow::ModesWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ModesWindow)
{
    ui->setupUi(this);
    //this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    QDesktopWidget *desktop = QApplication::desktop();//位于中央
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);

}




ModesWindow::~ModesWindow()
{
    delete ui;
}

void ModesWindow::on_pushButton_2_clicked()
{
    /*
    AutoTouristWindow *m = new AutoTouristWindow;
    m->show();
    */
    AutoFuncWindow* m = new AutoFuncWindow;

    m->show();
    this->close();
}

void ModesWindow::on_toolButton_clicked()
{
    SetPlaceWindow *m = new SetPlaceWindow;
    m->show();
    this->close();
}
