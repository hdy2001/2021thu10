#ifndef AUTOTOURISTWINDOW_H
#define AUTOTOURISTWINDOW_H

#include <QMainWindow>
#include "modeswindow.h"
#include <QDesktopWidget>
#include "autofuncwindow.h"

namespace Ui {
class AutoTouristWindow;
}

class AutoTouristWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AutoTouristWindow(QWidget *parent = 0);
    ~AutoTouristWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::AutoTouristWindow *ui;
};

#endif // AUTOTOURISTWINDOW_H
