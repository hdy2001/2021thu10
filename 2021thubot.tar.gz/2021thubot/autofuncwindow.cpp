#include "autofuncwindow.h"
#include "ui_autofuncwindow.h"
#include <QDebug>

AutoFuncWindow::AutoFuncWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AutoFuncWindow)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    QDesktopWidget *desktop = QApplication::desktop();//位于屏幕中央
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);
    //添加点击按钮下拉菜单功能
    QMenu *menu = new QMenu();
    this->mode1 = new QAction(menu);
    this->mode2 = new QAction(menu);


    //图标和文字设置
    QPixmap pixmap1(":/icons/components/icons/action/svg/production/ic_flight_takeoff_24px.svg");
    QIcon Icon_1(pixmap1);
    mode1->setIcon(Icon_1);

    QPixmap pixmap2(":/icons/components/icons/action/svg/production/ic_home_24px.svg");
    QIcon Icon_2(pixmap2);
    mode2->setIcon(Icon_2);

    mode1->setText("导游模式");
    //mode2->setText("定点模式");
    mode2->setText("跑腿模式");

    menu->addAction(mode1);
    menu->addAction(mode2);

    ui->FuncChooseButton->setMenu(menu);

    //样式设置
    menu->setStyleSheet(
                "QMenu{background:rgba(255,255,255,1);border:none;}"
                "QMenu::item{padding:3px 20px;color:rgba(51,51,51,1);font-size:12px;}"
                "QMenu::item:hover{background-color:#E0E0E0;}"
                "QMenu::item:selected{background-color:#E0E0E0;}");

    //一开始widget不可见
    ui->widget->close();
    ui->widget_2->close();

    //设置toggle状态


    //connenct函数区
    connect(mode1, &QAction::triggered, this, &AutoFuncWindow::slt_setPageWidget);
    connect(mode2, &QAction::triggered, this, &AutoFuncWindow::slt_setPageWidget);




}

AutoFuncWindow::~AutoFuncWindow()
{
    delete ui;
}

void AutoFuncWindow::on_pushButton_clicked()
{
    /*
    AutoTouristWindow *m = new AutoTouristWindow;
    m->show();
    */
    ModesWindow *m = new ModesWindow;
    m->show();
    this->close();
}

void AutoFuncWindow::on_FuncChooseButton_clicked()
{
    ui->FuncChooseButton->showMenu();
}

void AutoFuncWindow::slt_setPageWidget()
{
    //获取触发槽的是哪个部件所发出的信号，并获取到那个指针
    QAction *widget = qobject_cast<QAction*>(sender());
    //qDebug()<<widget->text();
    if (widget == this->mode1)
    {
        //qDebug()<<"hehe";
        ui->stackedWidget->setCurrentIndex(0);//根据触发的按钮来进行所要显示的QWidget
    }
    else if (widget == this->mode2)
    {
        //qDebug()<<"haha";
        ui->stackedWidget->setCurrentIndex(1);
    }

}

//导游模式按钮按下后的函数
void AutoFuncWindow::on_toolButton_2_toggled(bool checked)
{



    if(checked == true){
        //如果checked为true，运行脚本
        ui->widget_2->show();
        ui->FuncChooseButton->setEnabled(false);
        ui->pushButton->setEnabled(false);

    }

    if(checked == false){
        //如果checked为false，结束进程
        ui->widget_2->close();
        ui->FuncChooseButton->setEnabled(true);
        ui->pushButton->setEnabled(true);
    }



}

//定点模式按钮按下后的函数
void AutoFuncWindow::on_toolButton_toggled(bool checked)
{
    if(checked == true){
        //如果checked为true，运行脚本
        ui->widget->show();
        ui->FuncChooseButton->setEnabled(false);
        ui->pushButton->setEnabled(false);

    }

    if(checked == false){
        //如果checked为false，结束进程
        ui->widget->close();
        ui->FuncChooseButton->setEnabled(true);
        ui->pushButton->setEnabled(true);
    }
}
