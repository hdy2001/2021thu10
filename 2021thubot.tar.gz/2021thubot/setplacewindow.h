#ifndef SETPLACEWINDOW_H
#define SETPLACEWINDOW_H

#include <QWidget>
#include <QDesktopWidget>
#include "modeswindow.h"
#include <QStackedWidget>

namespace Ui {
class SetPlaceWindow;
}

class SetPlaceWindow : public QWidget
{
    Q_OBJECT

public:
    explicit SetPlaceWindow(QWidget *parent = 0);
    ~SetPlaceWindow();

private slots:
    void on_pushButton_clicked();

    void on_toolButton_clicked();

    void on_toolButton_2_clicked();

    void on_toolButton_3_clicked();

    void on_closeButton_clicked();

private:
    Ui::SetPlaceWindow *ui;
};

#endif // SETPLACEWINDOW_H
