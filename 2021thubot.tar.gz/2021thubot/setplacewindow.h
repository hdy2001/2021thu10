#ifndef SETPLACEWINDOW_H
#define SETPLACEWINDOW_H

#include <QWidget>
#include <QDesktopWidget>
#include "modeswindow.h"
#include <QStackedWidget>

namespace Ui {
class SetPlaceWindow;
}

class SetPlaceWindow : public QWidget
{
    Q_OBJECT

public:
    explicit SetPlaceWindow(QWidget *parent = 0);
    ~SetPlaceWindow();

private slots:
    void on_pushButton_clicked();

    void on_toolButton_clicked();

    void on_toolButton_2_clicked();

    void on_toolButton_3_clicked();

    void on_closeButton_clicked();

    //根据点击按钮显示功能窗口的槽
    void slt_setPageWidget();

    void on_toolButton_4_clicked();

    void on_toolButton_6_clicked();

    void on_toolButton_5_clicked();

private:
    Ui::SetPlaceWindow *ui;
    QAction *mode1;
    QAction *mode2;
    QAction *mode3;
};

#endif // SETPLACEWINDOW_H
