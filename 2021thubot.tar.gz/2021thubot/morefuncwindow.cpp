#include "morefuncwindow.h"
#include "ui_morefuncwindow.h"

MoreFuncWindow::MoreFuncWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MoreFuncWindow)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    QDesktopWidget *desktop = QApplication::desktop();//位于中央
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);
}

MoreFuncWindow::~MoreFuncWindow()
{
    delete ui;
}

void MoreFuncWindow::on_pushButton_2_clicked()
{
    this->close();
    ModesWindow *m = new ModesWindow;
    m->show();
}

void MoreFuncWindow::on_pushButton_clicked()
{
    this->close();
}

//刷脸签到按钮按下后的样子，自行填充
void MoreFuncWindow::on_toolButton_clicked()
{

}


//拍照按钮按下后的样子，自行填充
void MoreFuncWindow::on_toolButton_2_clicked()
{

}


//录像按钮按下的样子，自行填充
void MoreFuncWindow::on_toolButton_5_clicked()
{

}

//视频播放按钮，自行填充
void MoreFuncWindow::on_toolButton_3_clicked()
{

}


//测温按钮按下，自行填充
void MoreFuncWindow::on_toolButton_4_clicked()
{

}

//机械臂按钮按下，自行填充
void MoreFuncWindow::on_toolButton_6_clicked()
{

}
