#ifndef AUTOFUNCWINDOW_H
#define AUTOFUNCWINDOW_H

#include <QWidget>
#include <QMenu>
#include "autotouristwindow.h"
#include "modeswindow.h"
#include <QtGui>

namespace Ui {
class AutoFuncWindow;
}

class AutoFuncWindow : public QWidget
{
    Q_OBJECT

public:
    explicit AutoFuncWindow(QWidget *parent = 0);

    /*
    void paintEvent(QPaintEvent *event)
    {
        QPainter painter(this);
        painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/picture/image/2.jpg"));
    }
    */

    ~AutoFuncWindow();

private slots:
    void on_pushButton_clicked();

    void on_FuncChooseButton_clicked();

    //根据点击按钮显示功能窗口的槽
    void slt_setPageWidget();

    void on_toolButton_2_toggled(bool checked);

    void on_toolButton_toggled(bool checked);

private:
    Ui::AutoFuncWindow *ui;
    QAction *mode1;
    QAction *mode2;
};

#endif // AUTOFUNCWINDOW_H
