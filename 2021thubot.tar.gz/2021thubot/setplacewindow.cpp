#include "setplacewindow.h"
#include "ui_setplacewindow.h"

SetPlaceWindow::SetPlaceWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SetPlaceWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    QDesktopWidget *desktop = QApplication::desktop();//位于中央
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);

    //设置下拉菜单栏
    QMenu *menu = new QMenu();

    this->mode1 = new QAction(menu);
    this->mode2 = new QAction(menu);
    this->mode3 = new QAction(menu);

    mode1->setText("语音控制");
    mode2->setText("键盘控制");
    mode3->setText("手柄控制");

    menu->addAction(mode1);
    menu->addAction(mode2);
    menu->addAction(mode3);

    ui->WayToolButton->setMenu(menu);

    menu->setStyleSheet(
                "QMenu{background:rgba(255,255,255,1);border:none;}"
                "QMenu::item{padding:3px 20px;color:rgba(51,51,51,1);font-size:12px;}"
                "QMenu::item:hover{background-color:#E0E0E0;}"
                "QMenu::item:selected{background-color:#E0E0E0;}");


    //connect函数区
    connect(mode1, &QAction::triggered, this, &SetPlaceWindow::slt_setPageWidget);
    connect(mode2, &QAction::triggered, this, &SetPlaceWindow::slt_setPageWidget);
    connect(mode3, &QAction::triggered, this, &SetPlaceWindow::slt_setPageWidget);


}

SetPlaceWindow::~SetPlaceWindow()
{
    delete ui;
}

void SetPlaceWindow::on_pushButton_clicked()
{
    ModesWindow *m = new ModesWindow;
    m->show();
    this->close();
}

//建图按钮接口，填充函数
void SetPlaceWindow::on_toolButton_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);

     ui->toolButton->setEnabled(false);
     ui->toolButton_2->setEnabled(false);
     ui->toolButton_3->setEnabled(false);
     ui->pushButton->setEnabled(false);

}

//手柄控制接口，填充函数
void SetPlaceWindow::on_toolButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

    ui->toolButton->setEnabled(false);
    ui->toolButton_2->setEnabled(false);
    ui->toolButton_3->setEnabled(false);
    ui->pushButton->setEnabled(false);

}

//键盘控制接口，填充函数
void SetPlaceWindow::on_toolButton_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->toolButton->setEnabled(false);
    ui->toolButton_2->setEnabled(false);
    ui->toolButton_3->setEnabled(false);
    ui->pushButton->setEnabled(false);
}

//语音控制接口，填充函数
void SetPlaceWindow::on_toolButton_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->toolButton->setEnabled(false);
    ui->toolButton_2->setEnabled(false);
    ui->toolButton_3->setEnabled(false);
    ui->pushButton->setEnabled(false);
}

//目标跟随导航按钮，填充函数
void SetPlaceWindow::on_toolButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

    ui->toolButton->setEnabled(false);
    ui->toolButton_2->setEnabled(false);
    ui->toolButton_3->setEnabled(false);
    ui->pushButton->setEnabled(false);

}

//停止按钮停止进程
void SetPlaceWindow::on_closeButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

    ui->toolButton->setEnabled(true);
    ui->toolButton_2->setEnabled(true);
    ui->toolButton_3->setEnabled(true);
    ui->pushButton->setEnabled(true);

}

void SetPlaceWindow::slt_setPageWidget()
{
    //获取触发槽的是哪个部件所发出的信号，并获取到那个指针
    QAction *widget = qobject_cast<QAction*>(sender());
    //qDebug()<<widget->text();
    if (widget == this->mode1)
    {
        //qDebug()<<"hehe";
        ui->stackedWidget_2->setCurrentIndex(2);//根据触发的按钮来进行所要显示的QWidget
    }
    else if (widget == this->mode2)
    {
        //qDebug()<<"haha";
        ui->stackedWidget_2->setCurrentIndex(1);
    }
    else if (widget == this->mode3)
    {
        //qDebug()<<"haha";
        ui->stackedWidget_2->setCurrentIndex(0);
    }

}

void SetPlaceWindow::on_toolButton_4_clicked()
{
    this->close();
}




