#include "setplacewindow.h"
#include "ui_setplacewindow.h"

SetPlaceWindow::SetPlaceWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SetPlaceWindow)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    QDesktopWidget *desktop = QApplication::desktop();//位于中央
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);
}

SetPlaceWindow::~SetPlaceWindow()
{
    delete ui;
}

void SetPlaceWindow::on_pushButton_clicked()
{
    ModesWindow *m = new ModesWindow;
    m->show();
    this->close();
}

//建图按钮接口，填充函数
void SetPlaceWindow::on_toolButton_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}

//手柄导航接口，填充函数
void SetPlaceWindow::on_toolButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

//目标跟随导航按钮，填充函数
void SetPlaceWindow::on_toolButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

//停止按钮停止进程
void SetPlaceWindow::on_closeButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}
