#include "logwindow.h"
#include "ui_logwindow.h"
#include <QProgressDialog>

LogWindow::LogWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::LogWindow)
{
    ui->setupUi(this);
    //视频初始设置
    /*
    player = new QMediaPlayer;
    videoWidget = new QVideoWidget;
    player->setVideoOutput(videoWidget);
    player->setMedia(QUrl::fromLocalFile("/home/hedongyang/桌面/jirou.mp4"));
    videoWidget->show();
    player->play();
    ui->verticalLayout->addWidget(videoWidget);
    */
    //this->setStyleSheet("QMainWindow{background-image: url(/home/hedongyang/桌面/Moha_example.png)}");
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    setFixedSize(645,425); // 禁止改变窗口大小。
    QDesktopWidget *desktop = QApplication::desktop();//位于中央
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);
    /*
    //获取最小化、关闭按钮图标
    QPixmap minPix  = style()->standardPixmap(QStyle::SP_TitleBarMinButton);
    QPixmap closePix = style()->standardPixmap(QStyle::SP_TitleBarCloseButton);
    //设置最小化、关闭按钮图标
    ui->minButton->setIcon(minPix);
    ui->closeButton->setIcon(closePix);
    //设置鼠标移至按钮上的提示信息
    ui->minButton->setToolTip(tr("最小化"));
    ui->closeButton->setToolTip(tr("关闭"));
    //设置最小化、关闭按钮的样式
    ui->minButton->setStyleSheet("background-color:transparent;");
    ui->closeButton->setStyleSheet("background-color:transparent;");
    */
}

LogWindow::~LogWindow()
{
    delete ui;
}


void LogWindow::on_toolButton_clicked()
{

    this->close();
    Progress *n = new Progress;
    n->show();
}

void LogWindow::on_toolButton_2_clicked()
{
    this->close();
}
