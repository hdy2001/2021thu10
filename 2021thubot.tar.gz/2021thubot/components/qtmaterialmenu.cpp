#include "qtmaterialmenu.h"
#include "qtmaterialmenu_p.h"

QtMaterialMenu::QtMaterialMenu(QWidget *parent)
    : QWidget(parent)
{
}

QtMaterialMenu::~QtMaterialMenu()
{
}
