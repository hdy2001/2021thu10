#include "progress.h"
#include "ui_progress.h"

Progress::Progress(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Progress)
{
    ui->setupUi(this);
    //写一个计时器即可（一定时间进度条关闭）
    ModesWindow *m = new ModesWindow;
    m->show();
}

Progress::~Progress()
{
    delete ui;
}
